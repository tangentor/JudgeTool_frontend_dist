import{u as r}from"./index.e4ce814e.js";const{cookies:o}=r(),n=(e,s,t="5D")=>{o.set(e,s,t)},c=e=>o.get(e),a=e=>o.isKey(e),k=e=>o.remove(e);export{c as g,a as i,k as r,n as s};
